package com.alsadq.lifeos

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.*
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.format.DateTimeFormatter

class MainActivity : Activity() {
    private lateinit var db: LocalDb
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("lifeos", MODE_PRIVATE) }
    private val today get() = LocalDate.now().toString()
    private data class Task(val id: String, val label: String, val unlockLevel: Int = 1)
    private val allTasks = listOf(
        Task("wake", "ابدأ يومك من غير تصفح طويل"),
        Task("water", "اشرب مياه على فترات"),
        Task("walk", "امشِ 5–10 دقائق"),
        Task("learn", "تعلّم أو اقرأ 5 دقائق"),
        Task("recovery", "طبّق خطوة حماية من محفزات الإباحية"),
        Task("sleep", "ابعد الموبايل قبل النوم بـ10 دقائق"),
        Task("plan", "خطّط لأهم حاجة عايز تنجزها بكرة في 3 دقائق", 2),
        Task("tidy", "رتّب مكانك أو أغراضك لمدة 5 دقائق", 2),
        Task("move_plus", "اعمل 10 دقائق حركة مقصودة إضافية", 3),
        Task("focus", "جلسة تركيز واحدة لمدة 15 دقيقة من غير إشعارات", 4),
        Task("priorities", "اكتب 3 أولويات لليوم وابدأ بأهم واحدة", 4),
        Task("reflect", "راجع يومك 3 دقائق: إيه اللي نجح وإيه اللي هتعدّله؟", 5)
    )
    private fun tasksForLevel(level: Int) = allTasks.filter { it.unlockLevel <= level }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = LocalDb(this)
        if (!prefs.contains("start_date")) prefs.edit().putString("start_date", today).apply()
        // Initialize strict-level tracking separately so existing installs do not inherit old, incompatible progress.
        if (!prefs.contains("journey_start_date")) prefs.edit().putString("journey_start_date", today).apply()
        if (!prefs.contains("last_evaluated_date")) prefs.edit().putString("last_evaluated_date", LocalDate.now().minusDays(1).toString()).apply()
        processClosedDays()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 55)
        ReminderScheduler.schedule(this)
        render()
    }
    override fun onDestroy() { db.close(); super.onDestroy() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float = 16f, bold: Boolean = false): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.rgb(244, 247, 251))
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(dp(2), dp(5), dp(2), dp(5))
    }
    private fun button(s: String, action: () -> Unit) = Button(this).apply {
        text = s
        setTextColor(Color.rgb(11, 25, 40))
        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(124, 230, 193))
        setOnClickListener { action() }
    }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable().apply { setColor(Color.rgb(20,28,47)); cornerRadius = dp(16).toFloat(); setStroke(dp(1), Color.rgb(43,56,83)) }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(5), 0, dp(7)); layoutParams = lp
    }
    private fun addCard(title: String): LinearLayout {
        val c = card(); c.addView(text(title, 19f, true)); root.addView(c); return c
    }
    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(18))
            setBackgroundColor(Color.rgb(11,16,32))
        }
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
        root.addView(text("Alsadq Life OS", 26f, true))
        root.addView(text("نظام إبراهيم لتطوير الذات • يعمل دون إنترنت", 14f))
        val journeyStart = LocalDate.parse(prefs.getString("journey_start_date", today))
        val journeyDays = maxOf(1L, ChronoUnit.DAYS.between(journeyStart, LocalDate.now()) + 1)
        val levelNumber = prefs.getInt("current_level", 1).coerceIn(1, 5)
        val activeTasks = tasksForLevel(levelNumber)
        val doneToday = db.doneTasks(today)
        val done = activeTasks.count { doneToday.contains(it.id) }
        val targetDays = daysForLevel(levelNumber)
        val progressDays = prefs.getInt("level_progress_days", 0).coerceAtLeast(0)
        val c = addCard("المستوى $levelNumber • ${levelTitle(levelNumber)}")
        c.addView(text("اليوم ${minOf(progressDays + 1, targetDays)} من $targetDays في المستوى • اليوم $journeyDays من الرحلة", 14f))
        c.addView(text("أيام مكتملة متتالية في المستوى: $progressDays/$targetDays", 14f, true))
        val levelBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = targetDays; progress = progressDays }
        c.addView(levelBar)
        c.addView(text("إنجاز اليوم: $done/${activeTasks.size} مهمة مفتوحة في مستواك", 14f))
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = activeTasks.size; progress = done }
        c.addView(bar)
        c.addView(text("كل مستوى بيحتفظ بالمهام السابقة ويضيف مهام جديدة. لازم تكمّل كل المهام المفتوحة يوميًا؛ أي يوم ناقص يصفر عداد المستوى الحالي من غير ما ينزّلك لمستوى أقدم.", 13f))
        if (prefs.getString("last_reset_date", "") == today) {
            c.addView(text("اتعاد عداد المستوى بسبب يوم غير مكتمل. ابدأ من جديد من غير جلد ذات.", 13f, true))
        }
        if (done == activeTasks.size) c.addView(text("اكتملت مهام النهارده. حافظ عليها لحد نهاية اليوم؛ التقييم النهائي بيتم بعد انتهاء اليوم.", 13f, true))
        val taskCard = addCard("مهام اليوم • ${activeTasks.size} مهمة")
        activeTasks.forEach { task ->
            val cb = CheckBox(this).apply {
                text = task.label; textSize = 15f; isChecked = doneToday.contains(task.id)
                setOnCheckedChangeListener { _, checked -> db.setTask(today, task.id, checked); render() }
            }
            taskCard.addView(cb)
        }
        val nextLevelTasks = allTasks.filter { it.unlockLevel == levelNumber + 1 }
        if (nextLevelTasks.isNotEmpty()) {
            val preview = addCard("المهام اللي هتتفتح في المستوى التالي")
            nextLevelTasks.forEach { preview.addView(text("🔒 ${it.label}", 14f)) }
        }
        val controls = addCard("تطوير المستوى")
        controls.addView(text("المستوى لا يتقدم إلا بعد إكمال كل العادات الأساسية يوميًا طوال مدته. أي يوم ناقص يعيد عداد المستوى الحالي إلى الصفر، مع الاحتفاظ بتاريخك وعدم إنزالك لمستوى سابق.", 14f))
        controls.addView(button("تسجيل مراجعة الأسبوع") { weeklyReview() })
        controls.addView(button("تغيير تاريخ بداية الرحلة") { chooseStartDate() })
        controls.addView(button("تصدير نسخة احتياطية") { exportBackup() })
        val reminders = addCard("التذكيرات")
        val enabled = Switch(this).apply {
            text = "تذكيرات يومية (9 ص، 1 ظ، 6 م، 10 م)"
            isChecked = prefs.getBoolean("reminders_enabled", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("reminders_enabled", checked).apply()
                if (checked) ReminderScheduler.schedule(this@MainActivity)
                Toast.makeText(this@MainActivity, if(checked) "تم تفعيل التذكيرات" else "تم إيقاف التذكيرات", Toast.LENGTH_SHORT).show()
            }
        }
        reminders.addView(enabled)
        reminders.addView(button("إعدادات الإشعارات") { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) })
        val focus = addCard("تقليل تشتيت الموبايل")
        focus.addView(text("الحظر يعتمد على خدمة إمكانية الوصول، ولا تُفعّل إلا بموافقتك من إعدادات أندرويد. الخدمة ترجع للشاشة الرئيسية عند فتح تطبيق أضفته للقائمة.", 14f))
        focus.addView(button("إعدادات إمكانية الوصول") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        focus.addView(button("إضافة تطبيق لقائمة الحظر") { addBlockedDialog() })
        val blocked = db.blockedApps()
        focus.addView(text(if (blocked.isEmpty()) "قائمة الحظر فارغة." else "قائمة الحظر:\n" + blocked.joinToString("\n")))
        if (blocked.isNotEmpty()) focus.addView(button("إزالة تطبيق من القائمة") { removeBlockedDialog(blocked.toList()) })
        val notes = addCard("ملاحظاتك اليومية")
        val edit = EditText(this).apply { hint = "المحفزات، النوم، أو ملاحظة اليوم"; minLines = 2; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setText(db.note(today)) }
        notes.addView(edit)
        notes.addView(button("حفظ الملاحظات") { db.saveNote(today, edit.text.toString()); Toast.makeText(this, "اتحفظت الملاحظات على الجهاز", Toast.LENGTH_SHORT).show() })
        val disclaimer = addCard("مهم")
        disclaimer.addView(text("التطبيق لا يرسل بياناتك لأي خادم. اعمل نسخة احتياطية دوريًا. تقييم اليوم يحصل بعد انتهائه؛ اليوم الذي ينقصه أي عادة أساسية يصفر عداد المستوى الحالي. منبهات أندرويد قد تتأخر حسب وضع توفير البطارية. حظر التطبيقات ليس حماية مطلقة ويمكن تجاوزه بإيقاف صلاحية الخدمة.", 13f))
    }
    private fun daysForLevel(level: Int): Int = when (level) {
        1 -> 7
        2 -> 14
        3 -> 21
        4 -> 28
        else -> 35
    }

    private fun levelTitle(level: Int): String = when (level) {
        1 -> "التأسيس"
        2 -> "تثبيت العادات"
        3 -> "الجسم والطاقة"
        4 -> "التركيز والانضباط"
        else -> "الاستدامة"
    }

    /** Evaluate every closed day exactly once. Missing even one core habit resets progress
     * in the current level; it does not demote the user to a previous level. */
    private fun processClosedDays() {
        val start = LocalDate.parse(prefs.getString("journey_start_date", today))
        var last = LocalDate.parse(prefs.getString("last_evaluated_date", LocalDate.now().minusDays(1).toString()))
        val yesterday = LocalDate.now().minusDays(1)
        if (last >= yesterday) return
        var level = prefs.getInt("current_level", 1).coerceIn(1, 5)
        var progress = prefs.getInt("level_progress_days", 0).coerceAtLeast(0)
        var resetDate = ""
        var unlockedLevel = 0
        while (last < yesterday) {
            last = last.plusDays(1)
            if (last.isBefore(start)) continue
            val requiredTaskIds = tasksForLevel(level).map { it.id }
            val completed = db.doneTasks(last.toString()).containsAll(requiredTaskIds)
            if (completed) {
                progress = minOf(progress + 1, daysForLevel(level))
                if (progress >= daysForLevel(level) && level < 5) {
                    level += 1
                    progress = 0
                    unlockedLevel = level
                }
            } else {
                progress = 0
                resetDate = last.toString()
            }
        }
        prefs.edit()
            .putInt("current_level", level)
            .putInt("level_progress_days", progress)
            .putString("last_evaluated_date", yesterday.toString())
            .apply()
        if (resetDate.isNotEmpty()) {
            val editor = prefs.edit().putString("last_missed_date", resetDate)
            if (resetDate == yesterday.toString()) editor.putString("last_reset_date", today)
            else editor.remove("last_reset_date")
            editor.apply()
        } else {
            prefs.edit().remove("last_reset_date").apply()
        }
        if (unlockedLevel > 0) {
            Toast.makeText(this, "مبروك! فتحت المستوى $unlockedLevel • ${levelTitle(unlockedLevel)}", Toast.LENGTH_LONG).show()
        }
    }

    private fun chooseStartDate() {
        val d = LocalDate.parse(prefs.getString("start_date", today))
        DatePickerDialog(this, { _, y, m, day ->
            val date = LocalDate.of(y, m + 1, day)
            prefs.edit().putString("start_date", date.toString())
                .putString("journey_start_date", date.toString())
                .putString("last_evaluated_date", date.minusDays(1).toString())
                .putInt("current_level", 1)
                .putInt("level_progress_days", 0)
                .remove("last_reset_date")
                .remove("last_missed_date")
                .apply()
            render()
        }, d.year, d.monthValue - 1, d.dayOfMonth).show()
    }
    private fun weeklyReview() {
        val input = EditText(this).apply { hint = "إيه اللي نجح؟ وإيه أكبر عقبة؟"; minLines = 3; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setText(db.note(today)) }
        AlertDialog.Builder(this).setTitle("مراجعة الأسبوع").setView(input)
            .setPositiveButton("حفظ") { _, _ -> db.saveNote(today, "مراجعة أسبوعية: " + input.text.toString()); Toast.makeText(this, "اتحفظت المراجعة", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("إلغاء", null).show()
    }
    private fun addBlockedDialog() {
        val input = EditText(this).apply { hint = "اسم الحزمة مثل com.instagram.android"; inputType = 0x00000001; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
        AlertDialog.Builder(this).setTitle("إضافة تطبيق للحظر").setMessage("اكتب اسم الحزمة (Package name). مثال: com.instagram.android").setView(input)
            .setPositiveButton("إضافة") { _, _ ->
                val pkg = input.text.toString().trim()
                if (pkg.isNotEmpty() && pkg != packageName) { db.addBlockedApp(pkg); render() }
            }.setNegativeButton("إلغاء", null).show()
    }
    private fun removeBlockedDialog(items: List<String>) {
        AlertDialog.Builder(this).setTitle("إزالة تطبيق").setItems(items.toTypedArray()) { _, which -> db.removeBlockedApp(items[which]); render() }.show()
    }
    private fun exportBackup() {
        val data = StringBuilder("Alsadq Life OS backup\nstart_date=${prefs.getString("start_date", today)}\n")
        data.append("blocked_apps=").append(db.blockedApps().joinToString(",")).append("\n")
        val allDates = mutableSetOf<String>()
        for (i in 0..500) {
            val d = LocalDate.now().minusDays(i.toLong()).toString()
            val set = db.doneTasks(d)
            if (set.isNotEmpty()) { allDates.add(d); data.append(d).append("=").append(set.joinToString(",")).append("\n") }
        }
        val intent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, "Alsadq Life OS backup").putExtra(Intent.EXTRA_TEXT, data.toString())
        startActivity(Intent.createChooser(intent, "احفظ النسخة الاحتياطية"))
    }
}
