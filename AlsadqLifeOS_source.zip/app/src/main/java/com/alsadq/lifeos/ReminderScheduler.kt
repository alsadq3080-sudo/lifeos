package com.alsadq.lifeos

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object ReminderScheduler {
    fun schedule(context: Context) {
        val prefs = context.getSharedPreferences("lifeos", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("reminders_enabled", true)) return
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val reminders = listOf(
            Triple(101, 9, "اشرب مياه وخد دقيقة حركة."),
            Triple(102, 13, "راجع قائمة مهامك: خطوة صغيرة تكفي."),
            Triple(103, 18, "وقت 5 دقائق قراءة أو تعلّم."),
            Triple(104, 22, "جهّز للنوم وابعد الموبايل عن السرير.")
        )
        reminders.forEach { (id, hour, message) ->
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val intent = Intent(context, ReminderReceiver::class.java).putExtra("message", message)
            val pending = PendingIntent.getBroadcast(context, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis,
                AlarmManager.INTERVAL_DAY, pending)
        }
    }
}
