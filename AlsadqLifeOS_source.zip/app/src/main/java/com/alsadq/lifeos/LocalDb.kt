package com.alsadq.lifeos

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.time.LocalDate

class LocalDb(context: Context) : SQLiteOpenHelper(context, "lifeos.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE daily(date TEXT PRIMARY KEY, completed INTEGER NOT NULL DEFAULT 0, total INTEGER NOT NULL DEFAULT 6)")
        db.execSQL("CREATE TABLE task_done(date TEXT NOT NULL, task_id TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(date,task_id))")
        db.execSQL("CREATE TABLE blocked_apps(package_name TEXT PRIMARY KEY)")
        db.execSQL("CREATE TABLE notes(date TEXT PRIMARY KEY, note TEXT NOT NULL DEFAULT '')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun doneTasks(date: String = LocalDate.now().toString()): Set<String> {
        val out = mutableSetOf<String>()
        readableDatabase.rawQuery("SELECT task_id FROM task_done WHERE date=? AND done=1", arrayOf(date)).use { c ->
            while (c.moveToNext()) out.add(c.getString(0))
        }
        return out
    }
    fun setTask(date: String, id: String, done: Boolean) {
        val v = ContentValues().apply { put("date", date); put("task_id", id); put("done", if(done) 1 else 0) }
        writableDatabase.insertWithOnConflict("task_done", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun dayStats(date: String): Pair<Int,Int> {
        val d = doneTasks(date).size
        return Pair(d, 6)
    }
    fun saveNote(date: String, note: String) {
        val v = ContentValues().apply { put("date", date); put("note", note) }
        writableDatabase.insertWithOnConflict("notes", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun note(date: String): String {
        readableDatabase.rawQuery("SELECT note FROM notes WHERE date=?", arrayOf(date)).use { if (it.moveToFirst()) return it.getString(0) }
        return ""
    }
    fun blockedApps(): Set<String> {
        val out = mutableSetOf<String>()
        readableDatabase.rawQuery("SELECT package_name FROM blocked_apps", null).use { c -> while(c.moveToNext()) out.add(c.getString(0)) }
        return out
    }
    fun addBlockedApp(pkg: String) {
        val v = ContentValues().apply { put("package_name", pkg.trim()) }
        writableDatabase.insertWithOnConflict("blocked_apps", null, v, SQLiteDatabase.CONFLICT_IGNORE)
    }
    fun removeBlockedApp(pkg: String) { writableDatabase.delete("blocked_apps", "package_name=?", arrayOf(pkg)) }
    fun historyDays(): Int {
        readableDatabase.rawQuery("SELECT COUNT(DISTINCT date) FROM task_done", null).use { if(it.moveToFirst()) return it.getInt(0) }
        return 0
    }
}
