package com.alsadq.lifeos

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.content.Intent
import android.provider.Settings
import android.net.Uri

class AppBlockAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        val db = LocalDb(this)
        val blocked = try { db.blockedApps() } finally { db.close() }
        if (pkg in blocked) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            val prefs = getSharedPreferences("lifeos", MODE_PRIVATE)
            if (System.currentTimeMillis() - prefs.getLong("last_block_notice", 0L) > 30000) {
                prefs.edit().putLong("last_block_notice", System.currentTimeMillis()).apply()
                val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("blocked_notice", true)
                startActivity(i)
            }
        }
    }
    override fun onInterrupt() {}
}
