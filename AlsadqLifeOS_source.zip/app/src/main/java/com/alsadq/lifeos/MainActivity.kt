package com.alsadq.lifeos

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale

private val BG = Color.rgb(11, 18, 32)
private val NAV = Color.rgb(15, 23, 42)
private val CARD = Color.rgb(21, 30, 50)
private val CARD2 = Color.rgb(30, 42, 68)
private val EDGE = Color.rgb(36, 50, 78)
private val TEAL = Color.rgb(20, 184, 166)
private val BLUE = Color.rgb(59, 130, 246)
private val AMBER = Color.rgb(245, 158, 11)
private val TXT = Color.rgb(232, 238, 247)
private val MUTED = Color.rgb(143, 160, 184)

data class Level(
    val name: String,
    val emoji: String,
    val days: Int,
    val intro: String,
    val tasks: List<Pair<String, String>>,
    val plan: List<Pair<String, String>>
)

private val LEVELS = listOf(
    Level("الأساس", "🌱", 14,
        "الهدف: 4 عادات صغيرة جداً. مش مطلوب كمال، مطلوب انتظام. لو عملت الأربعة كل يوم 14 يوم متواصل يتفتح المستوى اللي بعده.",
        listOf(
            "phone_out" to "الموبايل ينام برا أوضتك (الشاحن في الصالة)",
            "sleep_time" to "نوم وصحيان في ميعاد ثابت",
            "water" to "6 أكواب مياه على مدار اليوم",
            "walk10" to "مشي 10 دقائق"
        ),
        listOf(
            "🌙 النوم" to "الشاحن برا الأوضة، والمنبه من الساعة الذكية بدل الموبايل. ميعاد نوم ثابت حتى لو النوم مجاش على طول.",
            "💧 المياه" to "كوب أول ما تصحى، وظبّط تذكير على الساعة الذكية كل ساعتين تقريباً.",
            "🚶 المشي" to "10 دقايق بعد أي وجبة أو الصبح. لو صعب عليك ابدأ بـ 5 دقايق.",
            "🎧 السماع" to "اسمع بودكاست أو محاضرة قصيرة وإنت ماشي، عن العادات أو الانضباط.",
            "🎵 الموسيقى" to "آلات هادئة أو كلاسيك أو أصوات طبيعة. ابعد عن الأغاني والفيديوهات اللي بتحرّك رغباتك.",
            "📱 تطبيقات" to "Forest للتركيز، وتطبيق حجب مواقع. وتقدر تفعّل DNS خاص بحجب المحتوى: الإعدادات ← DNS الخاص ← اكتب family.cloudflare-dns.com (مكانه بيختلف حسب الموبايل)."
        )),
    Level("الانضباط", "🛡️", 21,
        "دلوقتي بنضيف قراءة وتمرين وخطة للمحفزات. الفكرة إنك تجهّز ردّك قبل ما الرغبة تيجي.",
        listOf(
            "phone_out" to "الموبايل ينام برا أوضتك",
            "sleep_time" to "نوم وصحيان في ميعاد ثابت",
            "read10" to "اقرأ 10 صفحات (كتاب: العادات الذرية)",
            "workout10" to "تمرين منزلي 10 دقائق (ضغط + سكوات + بلانك)",
            "plan" to "اكتب محفزات اليوم المحتملة وخطتك لكل واحد (دقيقتين)"
        ),
        listOf(
            "📖 القراءة" to "كتاب: العادات الذرية (جيمس كلير). 10 صفحات يومياً من الأول.",
            "💪 التمرين" to "10 دقايق: 10 ضغط، 15 سكوات، بلانك 30 ثانية. زوّد شوية كل أسبوع.",
            "🧭 خطة المحفزات" to "اكتب: لو حصل (X) هعمل (Y). مثال: لو لقيت نفسي على السرير بالموبايل، أقوم أشرب مياه وأمشي دقيقتين.",
            "🎧 السماع" to "حلقات عن بناء العادات والتحكم في الرغبات، 15 دقيقة يومياً.",
            "🎵 الموسيقى" to "لو-فاي أو آلات أثناء القراءة، وإيقاع حماسي أثناء التمرين بس."
        )),
    Level("العمق", "🧠", 30,
        "بنضيف التركيز العميق والتدوين. الهدف تدريب العقل على الانتباه الطويل بدل التشتت.",
        listOf(
            "phone_out" to "الموبايل ينام برا أوضتك",
            "sleep_time" to "نوم وصحيان في ميعاد ثابت",
            "read15" to "اقرأ 15 صفحة",
            "workout15" to "تمرين 15 دقيقة",
            "focus25" to "جلسة تركيز 25 دقيقة بدون موبايل",
            "journal" to "دوّن 3 أشياء ممتن لها أو ملاحظة اليوم",
            "plan" to "اكتب محفزات اليوم وخطتك لها"
        ),
        listOf(
            "📖 القراءة" to "كتاب: الشغل العميق (Deep Work) لكال نيوبورت. 15 صفحة يومياً.",
            "🎯 التركيز" to "25 دقيقة تركيز و5 راحة، والموبايل في أوضة تانية أثناء الجلسة.",
            "📝 التدوين" to "3 أشياء ممتن لها وسطر عن اللي حصل النهارده. سطرين كفاية.",
            "💪 التمرين" to "15 دقيقة: ضغط وسكوات وبلانك وجري في المكان."
        )),
    Level("التثبيت", "🏔️", 60,
        "هنا العادات بتتحول لهوية. بنضيف مهارة جديدة وتركيز أطول.",
        listOf(
            "phone_out" to "الموبايل ينام برا أوضتك",
            "sleep_time" to "نوم وصحيان في ميعاد ثابت",
            "read15" to "اقرأ 15 صفحة",
            "workout20" to "تمرين 20 دقيقة",
            "focus45" to "جلسة تركيز 45 دقيقة بدون موبايل",
            "journal" to "دوّن 3 أشياء ممتن لها أو ملاحظة اليوم",
            "skill20" to "تعلّم مهارة جديدة 20 دقيقة"
        ),
        listOf(
            "📖 القراءة" to "كتاب: الإنسان يبحث عن المعنى (فيكتور فرانكل).",
            "🧩 المهارة" to "اختار مهارة واحدة (لغة، برمجة، كتابة) وكمّل عليها 20 دقيقة.",
            "💪 التمرين" to "20 دقيقة، وزوّد الصعوبة تدريجياً.",
            "🎯 التركيز" to "جلسة 45 دقيقة واحدة يومياً."
        )),
    Level("الاستدامة", "👑", 100000,
        "وصلت لأعلى مستوى. الشغل دلوقتي هو الحفاظ على النظام لحد نهاية الرحلة.",
        listOf(
            "phone_out" to "الموبايل ينام برا أوضتك",
            "sleep_time" to "نوم وصحيان في ميعاد ثابت",
            "read15" to "اقرأ 15 صفحة",
            "workout20" to "تمرين 20 دقيقة",
            "focus45" to "جلسة تركيز 45 دقيقة بدون موبايل",
            "journal" to "دوّن ملاحظة اليوم"
        ),
        listOf(
            "🔁 المراجعة" to "راجع أهدافك مرة كل شهر وعدّل اللي محتاج تعديل.",
            "🛟 لو حسيت بضغط" to "قلّل المهام مؤقتاً بدل ما تسيب كل حاجة."
        ))
)

class RingView(context: Context) : View(context) {
    var progress = 0f
    var centerText = ""
    var subText = ""
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(60, 255, 255, 255); strokeCap = Paint.Cap.ROUND }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeCap = Paint.Cap.ROUND }
    private val bigPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 255, 255, 255); textAlign = Paint.Align.CENTER }
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val stroke = w * 0.08f
        trackPaint.strokeWidth = stroke
        fillPaint.strokeWidth = stroke
        val size = minOf(w, h) - stroke
        val left = (w - size) / 2f
        val top = (h - size) / 2f
        val rect = RectF(left, top, left + size, top + size)
        canvas.drawArc(rect, 0f, 360f, false, trackPaint)
        val p = progress.coerceIn(0f, 1f)
        if (p > 0f) canvas.drawArc(rect, -90f, 360f * p, false, fillPaint)
        bigPaint.textSize = size * 0.26f
        canvas.drawText(centerText, w / 2f, h / 2f + bigPaint.textSize * 0.2f, bigPaint)
        smallPaint.textSize = size * 0.085f
        canvas.drawText(subText, w / 2f, h / 2f + size * 0.26f, smallPaint)
    }
}

class LineBar(context: Context) : View(context) {
    var progress = 0f
    var fillColor = Color.rgb(20, 184, 166)
    var trackColor = Color.argb(60, 255, 255, 255)
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        trackPaint.color = trackColor
        fillPaint.color = fillColor
        canvas.drawRoundRect(RectF(0f, 0f, w, h), r, r, trackPaint)
        val p = progress.coerceIn(0f, 1f)
        if (p > 0f) canvas.drawRoundRect(RectF(w - w * p, 0f, w, h), r, r, fillPaint)
    }
}

class BarsView(context: Context) : View(context) {
    var values: List<Float> = emptyList()
    var labels: List<String> = emptyList()
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(30, 42, 68) }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(20, 184, 166) }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(143, 160, 184); textAlign = Paint.Align.CENTER }
    override fun onDraw(canvas: Canvas) {
        val n = values.size
        if (n == 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        val slot = w / n
        val barW = slot * 0.5f
        val labelH = h * 0.22f
        val chartH = h - labelH
        textPaint.textSize = labelH * 0.55f
        for (i in 0 until n) {
            val cx = w - slot * (i + 0.5f)
            val left = cx - barW / 2f
            val right = cx + barW / 2f
            val r = barW / 2f
            canvas.drawRoundRect(RectF(left, 0f, right, chartH), r, r, trackPaint)
            val v = values[i].coerceIn(0f, 1f)
            if (v > 0f) canvas.drawRoundRect(RectF(left, chartH - chartH * v, right, chartH), r, r, fillPaint)
            val lab = if (i < labels.size) labels[i] else ""
            canvas.drawText(lab, cx, h - labelH * 0.2f, textPaint)
        }
    }
}

class HeatView(context: Context) : View(context) {
    var values: List<Float> = emptyList()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val n = values.size
        if (n == 0) return
        val cols = 7
        val rows = (n + cols - 1) / cols
        val w = width.toFloat()
        val h = height.toFloat()
        val cw = w / cols
        val ch = h / rows
        val gap = minOf(cw, ch) * 0.12f
        for (i in 0 until n) {
            val col = i % cols
            val row = i / cols
            val cx = w - cw * (col + 0.5f)
            val cy = ch * (row + 0.5f)
            val v = values[i].coerceIn(0f, 1f)
            paint.color = if (v <= 0f) Color.rgb(30, 42, 68) else Color.argb((70 + 185 * v).toInt(), 20, 184, 166)
            val r = minOf(cw, ch) * 0.2f
            canvas.drawRoundRect(RectF(cx - cw / 2f + gap, cy - ch / 2f + gap, cx + cw / 2f - gap, cy + ch / 2f - gap), r, r, paint)
        }
    }
}

class MainActivity : Activity() {
    private lateinit var db: LocalDb
    private lateinit var holder: FrameLayout
    private var tab = 0
    private var savedScroll = 0
    private val prefs by lazy { getSharedPreferences("lifeos", MODE_PRIVATE) }
    private val today get() = LocalDate.now().toString()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = NAV
        db = LocalDb(this)
        if (!prefs.contains("start_date")) prefs.edit().putString("start_date", today).apply()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 55)
        ReminderScheduler.schedule(this)
        render()
    }

    override fun onDestroy() { db.close(); super.onDestroy() }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(top: Int = 6, bottom: Int = 6): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(top), 0, dp(bottom)) }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun tv(s: String, size: Float = 15f, color: Int = TXT, bold: Boolean = false): TextView = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(dp(2), dp(4), dp(2), dp(4))
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rounded(CARD, 20, EDGE)
        layoutParams = lp(6, 6)
    }

    private fun btn(label: String, color: Int = TEAL, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 15f
        setTextColor(Color.WHITE)
        setTypeface(null, Typeface.BOLD)
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(13), dp(14), dp(13))
        background = rounded(color, 14)
        layoutParams = lp(5, 5)
        isClickable = true
        setOnClickListener { action() }
    }

    private fun field(hintText: String, value: String, lines: Int): EditText = EditText(this).apply {
        hint = hintText
        setText(value)
        minLines = lines
        textSize = 15f
        setTextColor(TXT)
        setHintTextColor(MUTED)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = rounded(CARD2, 12)
        gravity = Gravity.TOP or Gravity.START
        layoutParams = lp(6, 6)
    }

    private fun statCard(emoji: String, value: String, label: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(6), dp(12), dp(6), dp(12))
        background = rounded(CARD, 18, EDGE)
        val p = LinearLayout.LayoutParams(0, -2, 1f)
        p.setMargins(dp(4), 0, dp(4), 0)
        layoutParams = p
        addView(tv(emoji, 22f).apply { gravity = Gravity.CENTER })
        addView(tv(value, 20f, TXT, true).apply { gravity = Gravity.CENTER })
        addView(tv(label, 11f, MUTED).apply { gravity = Gravity.CENTER })
    }

    private fun sectionTitle(s: String): TextView = tv(s, 13f, MUTED, true).apply { setPadding(dp(4), dp(14), dp(4), dp(2)) }

    private fun iconFor(id: String): String = when {
        id.startsWith("phone") -> "📵"
        id.startsWith("sleep") -> "😴"
        id.startsWith("water") -> "💧"
        id.startsWith("walk") -> "🚶"
        id.startsWith("read") -> "📖"
        id.startsWith("workout") -> "💪"
        id.startsWith("plan") -> "🧭"
        id.startsWith("focus") -> "🎯"
        id.startsWith("journal") -> "📝"
        id.startsWith("skill") -> "🧩"
        else -> "✅"
    }

    // ---------- screen ----------
    private fun render() {
        val rootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            fitsSystemWindows = true
        }
        val h = LocalTime.now().hour
        val greet = if (h < 12) "صباح الخير 🌤️" else if (h < 18) "نهارك سعيد ☀️" else "مساء الخير 🌙"
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(6))
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        titleCol.addView(tv("Alsadq Life OS", 22f, TXT, true))
        titleCol.addView(tv(greet, 13f, MUTED))
        val chip = tv("🔥 " + streak(), 14f, AMBER, true).apply {
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = rounded(Color.rgb(58, 41, 10), 16)
        }
        header.addView(titleCol)
        header.addView(chip)
        holder = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        rootView.addView(header)
        rootView.addView(holder)
        rootView.addView(navBar())
        setContentView(rootView)
        renderContent()
    }

    private fun navBar(): LinearLayout {
        val items = listOf("🏠" to "الرئيسية", "🗺️" to "المستويات", "📚" to "الخطة", "📈" to "التقدم", "⚙️" to "المزيد")
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(NAV)
            setPadding(0, dp(6), 0, dp(6))
        }
        items.forEachIndexed { i, pair ->
            val sel = i == tab
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                isClickable = true
                setOnClickListener { tab = i; savedScroll = 0; render() }
            }
            val pill = TextView(this).apply {
                text = pair.first
                textSize = 20f
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(4), dp(18), dp(4))
                if (sel) background = rounded(Color.rgb(20, 60, 66), 16)
            }
            item.addView(pill)
            item.addView(tv(pair.second, 11f, if (sel) TEAL else MUTED, sel).apply { gravity = Gravity.CENTER })
            bar.addView(item)
        }
        return bar
    }

    private fun renderContent() {
        updateProgress()
        val old = holder.getChildAt(0)
        if (old is ScrollView) savedScroll = old.scrollY
        holder.removeAllViews()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }
        when (tab) {
            0 -> homePage(col)
            1 -> levelsPage(col)
            2 -> planPage(col)
            3 -> progressPage(col)
            else -> morePage(col)
        }
        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        sv.addView(col)
        holder.addView(sv)
        val y = savedScroll
        sv.post { sv.scrollTo(0, y) }
    }

    // ---------- pages ----------
    private fun homePage(col: LinearLayout) {
        val idx = levelIdx()
        val level = LEVELS[idx]
        val st = streak()
        val doneSet = db.doneTasks()
        val done = level.tasks.count { doneSet.contains(it.first) }
        val total = level.tasks.size
        val start = LocalDate.parse(prefs.getString("start_date", today))
        val dayNo = maxOf(1L, ChronoUnit.DAYS.between(start, LocalDate.now()) + 1)
        val left = ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.of(2027, 12, 31))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(15, 118, 110), Color.rgb(30, 64, 175))).apply { cornerRadius = dp(26).toFloat() }
            layoutParams = lp(6, 8)
        }
        hero.addView(tv(level.emoji + " المستوى " + (idx + 1) + " • " + level.name, 16f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        val ring = RingView(this)
        ring.progress = if (total == 0) 0f else done.toFloat() / total
        ring.centerText = "$done/$total"
        ring.subText = "مهام اليوم"
        ring.layoutParams = LinearLayout.LayoutParams(dp(180), dp(180)).apply { setMargins(0, dp(8), 0, dp(8)) }
        hero.addView(ring)
        if (level.days < 100000) {
            hero.addView(tv("سلسلتك $st من ${level.days} يوم متواصل لفتح المستوى اللي بعده", 13f, Color.WHITE).apply { gravity = Gravity.CENTER })
            val bar = LineBar(this)
            bar.progress = st.toFloat() / level.days
            bar.fillColor = Color.WHITE
            bar.layoutParams = LinearLayout.LayoutParams(-1, dp(8)).apply { setMargins(0, dp(6), 0, dp(4)) }
            hero.addView(bar)
        } else {
            hero.addView(tv("سلسلتك $st يوم متواصل • حافظ على المستوى", 13f, Color.WHITE).apply { gravity = Gravity.CENTER })
        }
        col.addView(hero)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = lp(6, 6) }
        row.addView(statCard("🔥", "$st", "يوم متواصل"))
        row.addView(statCard("📅", "$dayNo", "يوم من الرحلة"))
        row.addView(statCard("⏳", "$left", "يوم للهدف"))
        col.addView(row)

        col.addView(sectionTitle("مهام النهارده"))
        level.tasks.forEach { t -> col.addView(taskRow(t.first, t.second, doneSet.contains(t.first))) }

        if (done == total && total > 0) {
            val c = card()
            c.background = rounded(Color.rgb(16, 52, 58), 20, TEAL)
            c.addView(tv("🎉 خلّصت مهام النهارده", 17f, TXT, true))
            c.addView(tv("اليوم بيتحسب في السلسلة لما يخلص ويبدأ يوم جديد. كمّل كده.", 13f, MUTED))
            col.addView(c)
        }

        val slip = card()
        slip.addView(tv("💙 لو حصلت سقطة", 16f, TXT, true))
        slip.addView(tv("مش نهاية الطريق. سجّلها بصراحة وابدأ المستوى الحالي من أوله، وإنت بتتعلم من اللي حرّكها.", 13f, MUTED))
        slip.addView(btn("سجّلها وابدأ من جديد", CARD2) { slipDialog() })
        col.addView(slip)
    }

    private fun taskRow(id: String, label: String, done: Boolean): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = if (done) rounded(Color.rgb(16, 52, 58), 18, TEAL) else rounded(CARD, 18, EDGE)
            layoutParams = lp(4, 4)
            isClickable = true
            setOnClickListener { db.setTask(today, id, !done); renderContent() }
        }
        row.addView(tv(iconFor(id), 22f))
        val labelView = tv(label, 15f, if (done) MUTED else TXT).apply {
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setPadding(dp(12), 0, dp(12), 0)
            if (done) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        }
        row.addView(labelView)
        val check = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 15f
            setTextColor(Color.WHITE)
            text = if (done) "✓" else ""
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.OVAL
            if (done) shape.setColor(TEAL) else { shape.setColor(Color.TRANSPARENT); shape.setStroke(dp(2), MUTED) }
            background = shape
            layoutParams = LinearLayout.LayoutParams(dp(28), dp(28))
        }
        row.addView(check)
        return row
    }

    private fun levelsPage(col: LinearLayout) {
        val idx = levelIdx()
        col.addView(tv("رحلتك حتى 31 ديسمبر 2027", 20f, TXT, true))
        col.addView(tv("كل مستوى بيتفتح لما تلتزم بعدد أيام متواصلة. لو فاتك يوم، المستوى الحالي بيبدأ من أوله (مش من الصفر).", 13f, MUTED))
        var cum = 0
        LEVELS.forEachIndexed { i, lv ->
            val locked = i > idx
            val c = card()
            if (i == idx) c.background = rounded(Color.rgb(16, 52, 58), 20, TEAL)
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(tv(if (i < idx) "✅" else if (locked) "🔒" else lv.emoji, 26f))
            val t = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setPadding(dp(12), 0, dp(12), 0)
            }
            t.addView(tv("المستوى " + (i + 1) + " • " + lv.name, 17f, if (locked) MUTED else TXT, true))
            t.addView(tv(if (lv.days < 100000) lv.days.toString() + " يوم متواصل" else "مستمر حتى نهاية الرحلة", 13f, MUTED))
            head.addView(t)
            c.addView(head)
            if (i == idx && lv.days < 100000) {
                val bar = LineBar(this)
                bar.progress = streak().toFloat() / lv.days
                bar.layoutParams = LinearLayout.LayoutParams(-1, dp(8)).apply { setMargins(0, dp(8), 0, dp(4)) }
                c.addView(bar)
                c.addView(tv("سلسلتك: " + streak() + " من " + lv.days, 12f, MUTED))
            }
            if (i > 0 && i > idx) c.addView(tv("يتفتح بعد حوالي $cum يوم من الالتزام المتواصل", 12f, MUTED))
            c.addView(tv(lv.tasks.joinToString("\n") { "• " + it.second }, 13f, if (locked) MUTED else TXT))
            col.addView(c)
            if (lv.days < 100000) cum += lv.days
        }
    }

    private fun planPage(col: LinearLayout) {
        val idx = levelIdx()
        val level = LEVELS[idx]
        col.addView(tv(level.emoji + " خطة المستوى " + (idx + 1) + " • " + level.name, 20f, TXT, true))
        val intro = card()
        intro.addView(tv(level.intro, 14f, TXT))
        col.addView(intro)
        level.plan.forEach { p ->
            val c = card()
            c.addView(tv(p.first, 16f, TEAL, true))
            c.addView(tv(p.second, 14f, TXT))
            col.addView(c)
        }
        col.addView(tv("الاقتراحات دي نقطة بداية، غيّر فيها براحتك. المهم الانتظام مش الكمال.", 12f, MUTED))
    }

    private fun progressPage(col: LinearLayout) {
        val level = LEVELS[levelIdx()]
        val total = level.tasks.size
        col.addView(tv("تقدمك", 20f, TXT, true))
        val vals = ArrayList<Float>()
        val labs = ArrayList<String>()
        for (i in 6 downTo 0) {
            val d = LocalDate.now().minusDays(i.toLong())
            vals.add(minOf(1f, db.doneTasks(d.toString()).size.toFloat() / total))
            labs.add(d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale("ar")).take(3))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = lp(6, 6) }
        row.addView(statCard("🔥", "" + streak(), "يوم متواصل"))
        row.addView(statCard("✅", "" + db.historyDays(), "يوم سجّلت فيه"))
        row.addView(statCard("💙", "" + relapses().size, "مرة بدأت من جديد"))
        col.addView(row)
        val weekly = card()
        weekly.addView(tv("آخر 7 أيام", 16f, TXT, true))
        val bars = BarsView(this)
        bars.values = vals
        bars.labels = labs
        bars.layoutParams = LinearLayout.LayoutParams(-1, dp(150)).apply { setMargins(0, dp(10), 0, dp(4)) }
        weekly.addView(bars)
        col.addView(weekly)
        val heatCard = card()
        heatCard.addView(tv("آخر 28 يوم", 16f, TXT, true))
        val heat = HeatView(this)
        val hv = ArrayList<Float>()
        for (i in 27 downTo 0) {
            val d = LocalDate.now().minusDays(i.toLong())
            hv.add(minOf(1f, db.doneTasks(d.toString()).size.toFloat() / total))
        }
        heat.values = hv
        heat.layoutParams = LinearLayout.LayoutParams(-1, dp(120)).apply { setMargins(0, dp(10), 0, dp(4)) }
        heatCard.addView(heat)
        heatCard.addView(tv("كل مربع يوم، وكل ما كان لونه أقوى كل ما خلّصت مهام أكتر.", 12f, MUTED))
        col.addView(heatCard)
    }

    private fun morePage(col: LinearLayout) {
        col.addView(tv("المزيد", 20f, TXT, true))

        val reminders = card()
        reminders.addView(tv("🔔 التذكيرات", 17f, TXT, true))
        val enabled = Switch(this).apply {
            text = "تذكيرات يومية (9 ص، 1 ظ، 6 م، 10 م)"
            setTextColor(TXT)
            isChecked = prefs.getBoolean("reminders_enabled", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("reminders_enabled", checked).apply()
                if (checked) ReminderScheduler.schedule(this@MainActivity)
                Toast.makeText(this@MainActivity, if (checked) "تم تفعيل التذكيرات" else "تم إيقاف التذكيرات", Toast.LENGTH_SHORT).show()
            }
        }
        reminders.addView(enabled)
        reminders.addView(tv("لو عايز التذكيرات تظهر على الساعة الذكية، فعّل نسخ إشعارات التطبيقات من تطبيق الساعة.", 12f, MUTED))
        reminders.addView(btn("إعدادات الإشعارات", CARD2) { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) })
        col.addView(reminders)

        val focus = card()
        focus.addView(tv("🛡️ تقليل التشتيت", 17f, TXT, true))
        focus.addView(tv("الحظر يعتمد على خدمة إمكانية الوصول، ولا تتفعّل إلا بموافقتك من إعدادات أندرويد. الخدمة بترجّعك للشاشة الرئيسية لو فتحت تطبيق أضفته للقائمة.", 13f, MUTED))
        focus.addView(btn("إعدادات إمكانية الوصول", CARD2) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        focus.addView(btn("إضافة تطبيق لقائمة الحظر", CARD2) { addBlockedDialog() })
        val blocked = db.blockedApps()
        focus.addView(tv(if (blocked.isEmpty()) "قائمة الحظر فارغة." else "قائمة الحظر:\n" + blocked.joinToString("\n"), 13f, TXT))
        if (blocked.isNotEmpty()) focus.addView(btn("إزالة تطبيق من القائمة", CARD2) { removeBlockedDialog(blocked.toList()) })
        col.addView(focus)

        val notes = card()
        notes.addView(tv("📝 ملاحظة اليوم", 17f, TXT, true))
        val edit = field("المحفزات، النوم، أو ملاحظة اليوم", db.note(today), 3)
        notes.addView(edit)
        notes.addView(btn("حفظ الملاحظة") { db.saveNote(today, edit.text.toString()); Toast.makeText(this, "اتحفظت الملاحظة على الجهاز", Toast.LENGTH_SHORT).show() })
        notes.addView(btn("مراجعة الأسبوع", CARD2) { weeklyReview() })
        col.addView(notes)

        val data = card()
        data.addView(tv("💾 بياناتك", 17f, TXT, true))
        data.addView(btn("تصدير نسخة احتياطية", CARD2) { exportBackup() })
        data.addView(btn("إعادة ضبط تاريخ البداية (يصفّر المستويات)", CARD2) { chooseStartDate() })
        col.addView(data)

        val info = card()
        info.addView(tv("ℹ️ مهم", 17f, TXT, true))
        info.addView(tv("التطبيق لا يرسل بياناتك لأي خادم. اعمل نسخة احتياطية دوريًا. منبهات أندرويد غير الدقيقة قد تتأخر حسب وضع توفير البطارية. حظر التطبيقات ليس حماية مطلقة ويمكن تجاوزه بإيقاف صلاحية الخدمة. التطبيق مساعد للعادات وليس بديلاً عن مختص لو الأمر محتاج دعم.", 12f, MUTED))
        col.addView(info)
    }

    // ---------- logic ----------
    private fun levelIdx(): Int = prefs.getInt("level_idx", 0).coerceIn(0, LEVELS.size - 1)
    private fun streak(): Int = prefs.getInt("streak", 0)
    private fun relapses(): Set<String> = prefs.getStringSet("relapse_dates", emptySet<String>()) ?: emptySet<String>()

    private fun updateProgress() {
        val start = LocalDate.parse(prefs.getString("start_date", today))
        var last = LocalDate.parse(prefs.getString("last_check", start.minusDays(1).toString()))
        var idx = levelIdx()
        var st = streak()
        val rel = relapses()
        val yesterday = LocalDate.now().minusDays(1)
        var d = last.plusDays(1)
        while (!d.isAfter(yesterday)) {
            val ds = d.toString()
            val ids = LEVELS[idx].tasks.map { it.first }
            val ok = !rel.contains(ds) && db.doneTasks(ds).containsAll(ids)
            if (ok) {
                st++
                if (st >= LEVELS[idx].days && idx < LEVELS.size - 1) { idx++; st = 0 }
            } else {
                st = 0
            }
            last = d
            d = d.plusDays(1)
        }
        prefs.edit().putInt("level_idx", idx).putInt("streak", st).putString("last_check", last.toString()).apply()
        val seen = prefs.getInt("seen_level", 0)
        if (idx > seen) {
            prefs.edit().putInt("seen_level", idx).apply()
            AlertDialog.Builder(this).setTitle("مبروك! فتحت مستوى جديد")
                .setMessage("وصلت للمستوى ${idx + 1} • ${LEVELS[idx].name}. مهام جديدة اتضافت، واحدة واحدة.")
                .setPositiveButton("تمام", null).show()
        }
    }

    private fun slipDialog() {
        val input = EditText(this).apply { hint = "إيه اللي حرّكك (مكان/وقت/شعور)؟ وإيه اللي هتغيّره؟"; minLines = 3 }
        AlertDialog.Builder(this).setTitle("سجّلها بصراحة")
            .setMessage("هنرجّع عدّاد المستوى الحالي من الأول. ده مش عقاب، ده عشان تتعلم من اللي حصل.")
            .setView(input)
            .setPositiveButton("سجّل وابدأ من جديد") { _, _ ->
                val s = HashSet<String>(relapses())
                s.add(today)
                prefs.edit().putStringSet("relapse_dates", s).putInt("streak", 0).apply()
                val old = db.note(today)
                db.saveNote(today, (if (old.isEmpty()) "" else old + "\n") + "سقطة: " + input.text.toString())
                render()
            }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun chooseStartDate() {
        val d = LocalDate.parse(prefs.getString("start_date", today))
        DatePickerDialog(this, { _, y, m, day ->
            val date = LocalDate.of(y, m + 1, day)
            prefs.edit().putString("start_date", date.toString()).putInt("level_idx", 0).putInt("streak", 0).putInt("seen_level", 0).putString("last_check", date.minusDays(1).toString()).remove("relapse_dates").apply()
            render()
        }, d.year, d.monthValue - 1, d.dayOfMonth).show()
    }

    private fun weeklyReview() {
        val input = EditText(this).apply { hint = "إيه اللي نجح؟ وإيه أكبر عقبة؟"; minLines = 3; setText(db.note(today)) }
        AlertDialog.Builder(this).setTitle("مراجعة الأسبوع").setView(input)
            .setPositiveButton("حفظ") { _, _ -> db.saveNote(today, "مراجعة أسبوعية: " + input.text.toString()); Toast.makeText(this, "اتحفظت المراجعة", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun addBlockedDialog() {
        val input = EditText(this).apply { hint = "اسم الحزمة مثل com.instagram.android"; inputType = 0x00000001 }
        AlertDialog.Builder(this).setTitle("إضافة تطبيق للحظر").setMessage("اكتب اسم الحزمة (Package name). مثال: com.instagram.android").setView(input)
            .setPositiveButton("إضافة") { _, _ ->
                val pkg = input.text.toString().trim()
                if (pkg.isNotEmpty() && pkg != packageName) { db.addBlockedApp(pkg); renderContent() }
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun removeBlockedDialog(items: List<String>) {
        AlertDialog.Builder(this).setTitle("إزالة تطبيق").setItems(items.toTypedArray()) { _, which -> db.removeBlockedApp(items[which]); renderContent() }.show()
    }

    private fun exportBackup() {
        val data = StringBuilder("Alsadq Life OS backup\nstart_date=${prefs.getString("start_date", today)}\n")
        data.append("level=").append(levelIdx() + 1).append(" streak=").append(streak()).append("\n")
        data.append("slip_dates=").append(relapses().joinToString(",")).append("\n")
        data.append("blocked_apps=").append(db.blockedApps().joinToString(",")).append("\n")
        for (i in 0..500) {
            val d = LocalDate.now().minusDays(i.toLong()).toString()
            val set = db.doneTasks(d)
            if (set.isNotEmpty()) data.append(d).append("=").append(set.joinToString(",")).append("\n")
        }
        val intent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, "Alsadq Life OS backup").putExtra(Intent.EXTRA_TEXT, data.toString())
        startActivity(Intent.createChooser(intent, "احفظ النسخة الاحتياطية"))
    }
}
