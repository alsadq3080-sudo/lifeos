package com.alsadq.lifeos

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.*
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.format.DateTimeFormatter

class MainActivity : Activity() {
    private lateinit var db: LocalDb
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("lifeos", MODE_PRIVATE) }
    private val today get() = LocalDate.now().toString()
    private val tasks = listOf(
        "wake" to "ابدأ يومك من غير تصفح طويل",
        "water" to "اشرب مياه على فترات",
        "walk" to "امشِ 5–10 دقائق",
        "learn" to "تعلّم أو اقرأ 5 دقائق",
        "recovery" to "طبّق خطوة حماية من محفزات الإباحية",
        "sleep" to "ابعد الموبايل قبل النوم بـ10 دقائق"
    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = LocalDb(this)
        if (!prefs.contains("start_date")) prefs.edit().putString("start_date", today).apply()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 55)
        ReminderScheduler.schedule(this)
        render()
    }
    override fun onDestroy() { db.close(); super.onDestroy() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float = 16f, bold: Boolean = false): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.rgb(28, 38, 48))
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(dp(2), dp(5), dp(2), dp(5))
    }
    private fun button(s: String, action: () -> Unit) = Button(this).apply { text = s; setOnClickListener { action() } }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(16).toFloat(); setStroke(dp(1), Color.rgb(222,228,233)) }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(5), 0, dp(7)); layoutParams = lp
    }
    private fun addCard(title: String): LinearLayout {
        val c = card(); c.addView(text(title, 19f, true)); root.addView(c); return c
    }
    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(18))
            setBackgroundColor(Color.rgb(245,247,249))
        }
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
        root.addView(text("Alsadq Life OS", 26f, true))
        root.addView(text("نظام إبراهيم لتطوير الذات • يعمل دون إنترنت", 14f))
        val start = LocalDate.parse(prefs.getString("start_date", today))
        val days = maxOf(1L, ChronoUnit.DAYS.between(start, LocalDate.now()) + 1)
        val done = db.doneTasks().size
        val pct = (done * 100 / tasks.size)
        val level = levelFor(days, pct)
        val c = addCard("مستواك الحالي: ${level.first}")
        c.addView(text("اليوم $days من الرحلة • ${level.second}", 14f))
        c.addView(text("إنجاز اليوم: $done/${tasks.size} مهام"))
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = tasks.size; progress = done }
        c.addView(bar)
        val taskCard = addCard("مهام اليوم")
        tasks.forEach { (id, label) ->
            val cb = CheckBox(this).apply {
                text = label; textSize = 15f; isChecked = db.doneTasks().contains(id)
                setOnCheckedChangeListener { _, checked -> db.setTask(today, id, checked); render() }
            }
            taskCard.addView(cb)
        }
        val controls = addCard("تطوير المستوى")
        controls.addView(text("المستوى يتأثر بمرور الأيام وبنسبة إنجاز آخر أسبوع مسجل. لا تعتبر التقدم حكمًا على قيمتك.", 14f))
        controls.addView(button("تسجيل مراجعة الأسبوع") { weeklyReview() })
        controls.addView(button("تغيير تاريخ بداية الرحلة") { chooseStartDate() })
        controls.addView(button("تصدير نسخة احتياطية") { exportBackup() })
        val reminders = addCard("التذكيرات")
        val enabled = Switch(this).apply {
            text = "تذكيرات يومية (9 ص، 1 ظ، 6 م، 10 م)"
            isChecked = prefs.getBoolean("reminders_enabled", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("reminders_enabled", checked).apply()
                if (checked) ReminderScheduler.schedule(this@MainActivity)
                Toast.makeText(this@MainActivity, if(checked) "تم تفعيل التذكيرات" else "تم إيقاف التذكيرات", Toast.LENGTH_SHORT).show()
            }
        }
        reminders.addView(enabled)
        reminders.addView(button("إعدادات الإشعارات") { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) })
        val focus = addCard("تقليل تشتيت الموبايل")
        focus.addView(text("الحظر يعتمد على خدمة إمكانية الوصول، ولا تُفعّل إلا بموافقتك من إعدادات أندرويد. الخدمة ترجع للشاشة الرئيسية عند فتح تطبيق أضفته للقائمة.", 14f))
        focus.addView(button("إعدادات إمكانية الوصول") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        focus.addView(button("إضافة تطبيق لقائمة الحظر") { addBlockedDialog() })
        val blocked = db.blockedApps()
        focus.addView(text(if (blocked.isEmpty()) "قائمة الحظر فارغة." else "قائمة الحظر:\n" + blocked.joinToString("\n")))
        if (blocked.isNotEmpty()) focus.addView(button("إزالة تطبيق من القائمة") { removeBlockedDialog(blocked.toList()) })
        val notes = addCard("ملاحظاتك اليومية")
        val edit = EditText(this).apply { hint = "المحفزات، النوم، أو ملاحظة اليوم"; minLines = 2; setText(db.note(today)) }
        notes.addView(edit)
        notes.addView(button("حفظ الملاحظات") { db.saveNote(today, edit.text.toString()); Toast.makeText(this, "اتحفظت الملاحظات على الجهاز", Toast.LENGTH_SHORT).show() })
        val disclaimer = addCard("مهم")
        disclaimer.addView(text("التطبيق لا يرسل بياناتك لأي خادم. اعمل نسخة احتياطية دوريًا. منبهات أندرويد غير الدقيقة قد تتأخر حسب وضع توفير البطارية. حظر التطبيقات ليس حماية مطلقة ويمكن تجاوزه بإيقاف صلاحية الخدمة.", 13f))
    }
    private fun levelFor(days: Long, pct: Int): Pair<String,String> {
        val recentDays = (0..6).map { LocalDate.now().minusDays(it.toLong()).toString() }
        val doneCount = recentDays.sumOf { db.doneTasks(it).size }
        val possible = recentDays.size * tasks.size
        val rate = if (possible == 0) 0 else doneCount * 100 / possible
        return when {
            days < 7 -> "1 • التأسيس" to "ثبّت العادات الصغيرة؛ ${rate}% إنجاز مسجل آخر 7 أيام"
            days < 14 || rate < 35 -> "1 • التأسيس" to "نحتاج استمرارية قبل زيادة الحمل؛ ${rate}% آخر 7 أيام"
            days < 28 || rate < 55 -> "2 • تثبيت العادات" to "حافظ على المهام الأساسية؛ ${rate}% آخر 7 أيام"
            days < 56 || rate < 70 -> "3 • الحركة والتركيز" to "يمكن إضافة جلسات تركيز وتمارين بالتدريج؛ ${rate}% آخر 7 أيام"
            days < 90 || rate < 80 -> "4 • بناء القدرة" to "ثبّت روتينك وراجع المحفزات؛ ${rate}% آخر 7 أيام"
            else -> "5 • الاستدامة" to "حافظ على النظام وراجع أهدافك شهريًا؛ ${rate}% آخر 7 أيام"
        }
    }
    private fun chooseStartDate() {
        val d = LocalDate.parse(prefs.getString("start_date", today))
        DatePickerDialog(this, { _, y, m, day ->
            val date = LocalDate.of(y, m + 1, day)
            prefs.edit().putString("start_date", date.toString()).apply(); render()
        }, d.year, d.monthValue - 1, d.dayOfMonth).show()
    }
    private fun weeklyReview() {
        val input = EditText(this).apply { hint = "إيه اللي نجح؟ وإيه أكبر عقبة؟"; minLines = 3; setText(db.note(today)) }
        AlertDialog.Builder(this).setTitle("مراجعة الأسبوع").setView(input)
            .setPositiveButton("حفظ") { _, _ -> db.saveNote(today, "مراجعة أسبوعية: " + input.text.toString()); Toast.makeText(this, "اتحفظت المراجعة", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("إلغاء", null).show()
    }
    private fun addBlockedDialog() {
        val input = EditText(this).apply { hint = "اسم الحزمة مثل com.instagram.android"; inputType = 0x00000001 }
        AlertDialog.Builder(this).setTitle("إضافة تطبيق للحظر").setMessage("اكتب اسم الحزمة (Package name). مثال: com.instagram.android").setView(input)
            .setPositiveButton("إضافة") { _, _ ->
                val pkg = input.text.toString().trim()
                if (pkg.isNotEmpty() && pkg != packageName) { db.addBlockedApp(pkg); render() }
            }.setNegativeButton("إلغاء", null).show()
    }
    private fun removeBlockedDialog(items: List<String>) {
        AlertDialog.Builder(this).setTitle("إزالة تطبيق").setItems(items.toTypedArray()) { _, which -> db.removeBlockedApp(items[which]); render() }.show()
    }
    private fun exportBackup() {
        val data = StringBuilder("Alsadq Life OS backup\nstart_date=${prefs.getString("start_date", today)}\n")
        data.append("blocked_apps=").append(db.blockedApps().joinToString(",")).append("\n")
        val allDates = mutableSetOf<String>()
        for (i in 0..500) {
            val d = LocalDate.now().minusDays(i.toLong()).toString()
            val set = db.doneTasks(d)
            if (set.isNotEmpty()) { allDates.add(d); data.append(d).append("=").append(set.joinToString(",")).append("\n") }
        }
        val intent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, "Alsadq Life OS backup").putExtra(Intent.EXTRA_TEXT, data.toString())
        startActivity(Intent.createChooser(intent, "احفظ النسخة الاحتياطية"))
    }
}
