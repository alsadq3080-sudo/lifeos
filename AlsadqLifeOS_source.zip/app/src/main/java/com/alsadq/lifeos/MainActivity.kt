package com.alsadq.lifeos

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.*
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.format.DateTimeFormatter


data class Level(val name: String, val days: Int, val tasks: List<Pair<String, String>>, val tips: String)

private val LEVELS = listOf(
    Level("الأساس", 14, listOf(
        "phone_out" to "الموبايل ينام برا أوضتك (الشاحن في الصالة)",
        "sleep_time" to "نوم وصحيان في ميعاد ثابت",
        "water" to "6 أكواب مياه على مدار اليوم",
        "walk10" to "مشي 10 دقائق"
    ), "اقتراحات (غيّرها براحتك):\n• موسيقى: آلات هادئة أو أصوات طبيعة بدون أغاني مثيرة.\n• تطبيق: Forest للتركيز، وتطبيق حجب مواقع على الموبايل.\n• الهدف دلوقتي مش الكمال، الهدف إنك تعمل الأربع حاجات دول كل يوم."),
    Level("الانضباط", 21, listOf(
        "phone_out" to "الموبايل ينام برا أوضتك",
        "sleep_time" to "نوم وصحيان في ميعاد ثابت",
        "read10" to "اقرأ 10 صفحات (كتاب: العادات الذرية)",
        "workout10" to "تمرين منزلي 10 دقائق (ضغط + سكوات + بلانك)",
        "plan" to "اكتب محفزات اليوم المحتملة وخطتك لكل واحد (دقيقتين)"
    ), "اقتراحات:\n• كتاب: العادات الذرية (جيمس كلير).\n• موسيقى أثناء القراءة: آلات هادئة أو لو-فاي.\n• خطة المحفزات: لو حصل (X) هعمل (Y)، مثال: لو لقيت نفسي على السرير بالموبايل، أقوم أشرب مياه وأمشي دقيقتين."),
    Level("العمق", 30, listOf(
        "phone_out" to "الموبايل ينام برا أوضتك",
        "sleep_time" to "نوم وصحيان في ميعاد ثابت",
        "read15" to "اقرأ 15 صفحة",
        "workout15" to "تمرين 15 دقيقة",
        "focus25" to "جلسة تركيز 25 دقيقة بدون موبايل",
        "journal" to "دوّن 3 أشياء ممتن لها أو ملاحظة اليوم",
        "plan" to "اكتب محفزات اليوم وخطتك لها"
    ), "اقتراحات:\n• كتاب: الشغل العميق (Deep Work) لكال نيوبورت.\n• جلسة التركيز: 25 دقيقة شغل ثم 5 راحة.\n• التدوين: سطرين كفاية، المهم الانتظام."),
    Level("التثبيت", 60, listOf(
        "phone_out" to "الموبايل ينام برا أوضتك",
        "sleep_time" to "نوم وصحيان في ميعاد ثابت",
        "read15" to "اقرأ 15 صفحة",
        "workout20" to "تمرين 20 دقيقة",
        "focus45" to "جلسة تركيز 45 دقيقة بدون موبايل",
        "journal" to "دوّن 3 أشياء ممتن لها أو ملاحظة اليوم",
        "skill20" to "تعلّم مهارة جديدة 20 دقيقة"
    ), "اقتراحات:\n• كتاب: الإنسان يبحث عن المعنى (فيكتور فرانكل).\n• المهارة: اختار حاجة واحدة (لغة، برمجة، كتابة) وكمّل عليها."),
    Level("الاستدامة", 100000, listOf(
        "phone_out" to "الموبايل ينام برا أوضتك",
        "sleep_time" to "نوم وصحيان في ميعاد ثابت",
        "read15" to "اقرأ 15 صفحة",
        "workout20" to "تمرين 20 دقيقة",
        "focus45" to "جلسة تركيز 45 دقيقة بدون موبايل",
        "journal" to "دوّن ملاحظة اليوم"
    ), "حافظ على النظام وراجع أهدافك مرة كل شهر. لو حسيت إنك مضغوط، قلّل المهام بدل ما تسيب كل حاجة.")
)

class MainActivity : Activity() {
    private lateinit var db: LocalDb
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("lifeos", MODE_PRIVATE) }
    private val today get() = LocalDate.now().toString()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = LocalDb(this)
        if (!prefs.contains("start_date")) prefs.edit().putString("start_date", today).apply()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 55)
        ReminderScheduler.schedule(this)
        render()
    }
    override fun onDestroy() { db.close(); super.onDestroy() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float = 16f, bold: Boolean = false): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.rgb(28, 38, 48))
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(dp(2), dp(5), dp(2), dp(5))
    }
    private fun button(s: String, action: () -> Unit) = Button(this).apply { text = s; setOnClickListener { action() } }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(16).toFloat(); setStroke(dp(1), Color.rgb(222,228,233)) }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(5), 0, dp(7)); layoutParams = lp
    }
    private fun addCard(title: String): LinearLayout {
        val c = card(); c.addView(text(title, 19f, true)); root.addView(c); return c
    }
    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(18))
            setBackgroundColor(Color.rgb(245,247,249))
        }
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
        root.addView(text("Alsadq Life OS", 26f, true))
        root.addView(text("نظام إبراهيم لتطوير الذات • يعمل دون إنترنت", 14f))
        updateProgress()
        val start = LocalDate.parse(prefs.getString("start_date", today))
        val days = maxOf(1L, ChronoUnit.DAYS.between(start, LocalDate.now()) + 1)
        val left = ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.of(2027, 12, 31))
        val idx = levelIdx()
        val level = LEVELS[idx]
        val streakNow = streak()
        val doneSet = db.doneTasks()
        val done = level.tasks.count { doneSet.contains(it.first) }
        val c = addCard("مستواك الحالي: ${idx + 1} • ${level.name}")
        c.addView(text("اليوم $days من الرحلة • باقي $left يوم على 31 ديسمبر 2027", 14f))
        if (level.days < 100000) {
            c.addView(text("سلسلتك: $streakNow من ${level.days} يوم متواصل لفتح المستوى اللي بعده", 14f))
            c.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = level.days; progress = streakNow })
        } else {
            c.addView(text("سلسلتك: $streakNow يوم متواصل • وصلت لأعلى مستوى، حافظ عليه", 14f))
        }
        c.addView(text("إنجاز اليوم: $done/${level.tasks.size} مهام • اليوم بيتحسب في السلسلة لما تخلّص كل المهام وتبدأ يوم جديد", 13f))
        c.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = level.tasks.size; progress = done })
        val taskCard = addCard("مهام اليوم")
        level.tasks.forEach { (id, label) ->
            val cb = CheckBox(this).apply {
                text = label; textSize = 15f; isChecked = doneSet.contains(id)
                setOnCheckedChangeListener { _, checked -> db.setTask(today, id, checked); render() }
            }
            taskCard.addView(cb)
        }
        val tipsCard = addCard("تفاصيل المستوى")
        tipsCard.addView(text(level.tips, 14f))
        val slip = addCard("لو حصلت سقطة")
        slip.addView(text("السقطة مش نهاية الطريق. سجّلها بصراحة وهنرجّع عدّاد المستوى الحالي من الأول (مش من المستوى 1)، وإنت بتتعلم من اللي حرّكها.", 14f))
        slip.addView(button("سجّل سقطة وابدأ المستوى من جديد") { slipDialog() })
        val controls = addCard("تطوير المستوى")
        controls.addView(text("كل مستوى له عدد أيام متواصلة. اليوم بيتحسب لو خلّصت كل مهامه، ولو يوم فاتك يرجع عدّاد المستوى الحالي من الأول. لا تعتبر التقدم حكمًا على قيمتك.", 14f))
        controls.addView(button("تسجيل مراجعة الأسبوع") { weeklyReview() })
        controls.addView(button("إعادة ضبط تاريخ البداية (يصفّر المستويات)") { chooseStartDate() })
        controls.addView(button("تصدير نسخة احتياطية") { exportBackup() })
        val reminders = addCard("التذكيرات")
        val enabled = Switch(this).apply {
            text = "تذكيرات يومية (9 ص، 1 ظ، 6 م، 10 م)"
            isChecked = prefs.getBoolean("reminders_enabled", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("reminders_enabled", checked).apply()
                if (checked) ReminderScheduler.schedule(this@MainActivity)
                Toast.makeText(this@MainActivity, if(checked) "تم تفعيل التذكيرات" else "تم إيقاف التذكيرات", Toast.LENGTH_SHORT).show()
            }
        }
        reminders.addView(enabled)
        reminders.addView(button("إعدادات الإشعارات") { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) })
        val focus = addCard("تقليل تشتيت الموبايل")
        focus.addView(text("الحظر يعتمد على خدمة إمكانية الوصول، ولا تُفعّل إلا بموافقتك من إعدادات أندرويد. الخدمة ترجع للشاشة الرئيسية عند فتح تطبيق أضفته للقائمة.", 14f))
        focus.addView(button("إعدادات إمكانية الوصول") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        focus.addView(button("إضافة تطبيق لقائمة الحظر") { addBlockedDialog() })
        val blocked = db.blockedApps()
        focus.addView(text(if (blocked.isEmpty()) "قائمة الحظر فارغة." else "قائمة الحظر:\n" + blocked.joinToString("\n")))
        if (blocked.isNotEmpty()) focus.addView(button("إزالة تطبيق من القائمة") { removeBlockedDialog(blocked.toList()) })
        val notes = addCard("ملاحظاتك اليومية")
        val edit = EditText(this).apply { hint = "المحفزات، النوم، أو ملاحظة اليوم"; minLines = 2; setText(db.note(today)) }
        notes.addView(edit)
        notes.addView(button("حفظ الملاحظات") { db.saveNote(today, edit.text.toString()); Toast.makeText(this, "اتحفظت الملاحظات على الجهاز", Toast.LENGTH_SHORT).show() })
        val disclaimer = addCard("مهم")
        disclaimer.addView(text("التطبيق لا يرسل بياناتك لأي خادم. اعمل نسخة احتياطية دوريًا. منبهات أندرويد غير الدقيقة قد تتأخر حسب وضع توفير البطارية. حظر التطبيقات ليس حماية مطلقة ويمكن تجاوزه بإيقاف صلاحية الخدمة.", 13f))
    }
    private fun levelIdx(): Int = prefs.getInt("level_idx", 0).coerceIn(0, LEVELS.size - 1)
    private fun streak(): Int = prefs.getInt("streak", 0)
    private fun relapses(): Set<String> = prefs.getStringSet("relapse_dates", emptySet<String>()) ?: emptySet<String>()
    private fun updateProgress() {
        val start = LocalDate.parse(prefs.getString("start_date", today))
        var last = LocalDate.parse(prefs.getString("last_check", start.minusDays(1).toString()))
        var idx = levelIdx()
        var st = streak()
        val rel = relapses()
        val yesterday = LocalDate.now().minusDays(1)
        var d = last.plusDays(1)
        while (!d.isAfter(yesterday)) {
            val ds = d.toString()
            val ids = LEVELS[idx].tasks.map { it.first }
            val ok = !rel.contains(ds) && db.doneTasks(ds).containsAll(ids)
            if (ok) {
                st++
                if (st >= LEVELS[idx].days && idx < LEVELS.size - 1) { idx++; st = 0 }
            } else {
                st = 0
            }
            last = d
            d = d.plusDays(1)
        }
        prefs.edit().putInt("level_idx", idx).putInt("streak", st).putString("last_check", last.toString()).apply()
        val seen = prefs.getInt("seen_level", 0)
        if (idx > seen) {
            prefs.edit().putInt("seen_level", idx).apply()
            AlertDialog.Builder(this).setTitle("مبروك! فتحت مستوى جديد")
                .setMessage("وصلت للمستوى ${idx + 1} • ${LEVELS[idx].name}. مهام جديدة اتضافت، واحدة واحدة.")
                .setPositiveButton("تمام", null).show()
        }
    }
    private fun slipDialog() {
        val input = EditText(this).apply { hint = "إيه اللي حرّكك (مكان/وقت/شعور)؟ وإيه اللي هتغيّره؟"; minLines = 3 }
        AlertDialog.Builder(this).setTitle("سجّلها بصراحة")
            .setMessage("هنرجّع عدّاد المستوى الحالي من الأول. ده مش عقاب، ده عشان تتعلم من اللي حصل.")
            .setView(input)
            .setPositiveButton("سجّل وابدأ من جديد") { _, _ ->
                val s = HashSet<String>(relapses())
                s.add(today)
                prefs.edit().putStringSet("relapse_dates", s).putInt("streak", 0).apply()
                val old = db.note(today)
                db.saveNote(today, (if (old.isEmpty()) "" else old + "\n") + "سقطة: " + input.text.toString())
                render()
            }
            .setNegativeButton("إلغاء", null).show()
    }
    private fun chooseStartDate() {
        val d = LocalDate.parse(prefs.getString("start_date", today))
        DatePickerDialog(this, { _, y, m, day ->
            val date = LocalDate.of(y, m + 1, day)
            prefs.edit().putString("start_date", date.toString()).putInt("level_idx", 0).putInt("streak", 0).putInt("seen_level", 0).putString("last_check", date.minusDays(1).toString()).remove("relapse_dates").apply(); render()
        }, d.year, d.monthValue - 1, d.dayOfMonth).show()
    }
    private fun weeklyReview() {
        val input = EditText(this).apply { hint = "إيه اللي نجح؟ وإيه أكبر عقبة؟"; minLines = 3; setText(db.note(today)) }
        AlertDialog.Builder(this).setTitle("مراجعة الأسبوع").setView(input)
            .setPositiveButton("حفظ") { _, _ -> db.saveNote(today, "مراجعة أسبوعية: " + input.text.toString()); Toast.makeText(this, "اتحفظت المراجعة", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("إلغاء", null).show()
    }
    private fun addBlockedDialog() {
        val input = EditText(this).apply { hint = "اسم الحزمة مثل com.instagram.android"; inputType = 0x00000001 }
        AlertDialog.Builder(this).setTitle("إضافة تطبيق للحظر").setMessage("اكتب اسم الحزمة (Package name). مثال: com.instagram.android").setView(input)
            .setPositiveButton("إضافة") { _, _ ->
                val pkg = input.text.toString().trim()
                if (pkg.isNotEmpty() && pkg != packageName) { db.addBlockedApp(pkg); render() }
            }.setNegativeButton("إلغاء", null).show()
    }
    private fun removeBlockedDialog(items: List<String>) {
        AlertDialog.Builder(this).setTitle("إزالة تطبيق").setItems(items.toTypedArray()) { _, which -> db.removeBlockedApp(items[which]); render() }.show()
    }
    private fun exportBackup() {
        val data = StringBuilder("Alsadq Life OS backup\nstart_date=${prefs.getString("start_date", today)}\n")
        data.append("level=").append(levelIdx() + 1).append(" streak=").append(streak()).append("\n")
        data.append("slip_dates=").append(relapses().joinToString(",")).append("\n")
        data.append("blocked_apps=").append(db.blockedApps().joinToString(",")).append("\n")
        val allDates = mutableSetOf<String>()
        for (i in 0..500) {
            val d = LocalDate.now().minusDays(i.toLong()).toString()
            val set = db.doneTasks(d)
            if (set.isNotEmpty()) { allDates.add(d); data.append(d).append("=").append(set.joinToString(",")).append("\n") }
        }
        val intent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, "Alsadq Life OS backup").putExtra(Intent.EXTRA_TEXT, data.toString())
        startActivity(Intent.createChooser(intent, "احفظ النسخة الاحتياطية"))
    }
}
